while true
      do
          ps -ef | grep "kgminerproxy" | grep -v "grep"
          if [ "$?" -eq 1 ]
              then
              ./kgminerproxy $1 $2 $3 $4 $5 $6 $7 $8
          fi
          sleep 5
done
