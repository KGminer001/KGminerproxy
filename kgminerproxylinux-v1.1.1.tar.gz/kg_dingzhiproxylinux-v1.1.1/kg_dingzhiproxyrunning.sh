while true
      do
          ps -ef | grep "kg_dingzhiproxy" | grep -v "grep"
          if [ "$?" -eq 1 ]
              then
              ./kg_dingzhiproxy $1 $2 $3 $4 $5 $6 $7 $8
          fi
          sleep 5
done
